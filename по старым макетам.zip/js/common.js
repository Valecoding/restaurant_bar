'use strict';

/**
 *
 *  Take clients width and height
 *
 */
window.$ = window.jquery = $;

var w = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;

var h = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;

var x = document.getElementById('demo');

var psevdoLi = function psevdoLi() {
    var mark = void 0,
        container = void 0,
        ordersList = void 0;
    container = document.querySelector('.orders>li:last-of-type');
    mark = '<li class=\'no-id\' style=\'width: 1px; background-color: transparent; -webkit-box-shadow: none;-moz-box-shadow: none;box-shadow: none ; margin-right: 0; padding: 0;\'></li>';
    container.insertAdjacentHTML('afterend', mark);
};
psevdoLi();

function buttonMonthNav(dateTitle) {
    var namearrmonth = void 0;

    namearrmonth = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'];
    var returnIndex = function returnIndex() {
        return namearrmonth.findIndex(function (element, index) {
            if (element === dateTitle) {
                return index;
            } else {
                return false;
            }
        });
    };
    return {
        prev: namearrmonth[returnIndex() - 1],
        next: namearrmonth[returnIndex() + 1]
    };
}

$(document).ready(function () {
    var titleMonth = void 0;
    /*const calculator = ()=>{*/
    var $datepicker = $('#datepicker');
    //получаем до инклуда в ДОМ сам каллендарь
    var widget = $datepicker.datepicker('widget');

    function settings() {
        //работает отлично
        //общие настройки
        $datepicker.datepicker({
            showOn: 'button',
            buttonImageOnly: false,
            buttonText: 'сегодня&nbsp;<svg aria-hidden="true" data-prefix="fas"\n' + '                     data-icon="chevron-down"\n' + '                     class="svg-inline--fa fa-chevron-down fa-w-14" role="img"\n' + '                     xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path\n' + '                            fill="currentColor"\n' + '                            d="M207.029 381.476L12.686 187.132c-9.373-9.373-9.373-24.569 0-33.941l22.667-22.667c9.357-9.357 24.522-9.375 33.901-.04L224 284.505l154.745-154.021c9.379-9.335 24.544-9.317 33.901.04l22.667 22.667c9.373 9.373 9.373 24.569 0 33.941L240.971 381.476c-9.373 9.372-24.569 9.372-33.942 0z"></path></svg>',
            showOtherMonths: true,
            selectOtherMonths: true,
            navigationAsDateFormat: true
        });
        //русификация
        $datepicker.datepicker($.datepicker.regional['ru']);
        $datepicker.datepicker('setDate', new Date());

        //перенос
        if (widget.length > 0) {
            var calendar = $('#ui-datepicker-div');
            if (calendar.length > 0) {
                calendar.appendTo($('.with_callendar'));
            } else {
                console.log('-1');
            }
        }
    }

    settings();

    titleMonth = $('.ui-datepicker-month').text();

    function refreshCal(newMonth) {
        var navmonth = buttonMonthNav(newMonth);
        console.log(navmonth);
        $datepicker.datepicker('option', {
            nextText: navmonth.next,
            prevText: navmonth.prev
        });
        // $datepicker.datepicker("refresh");
    }
    function refreshCal2(newMonth) {
        var navmonth = buttonMonthNav(newMonth);
        console.log(navmonth);
        $('.ui-datepicker-next span').text(navmonth.next);
        $('.ui-datepicker-prev span').text(navmonth.prev);
    }
    console.log(titleMonth);
    refreshCal(titleMonth);

    // console.log(widget);
    $(widget).on('click', function (ev) {
        ev.preventDefault();
        var element = ev.target.innerText;

        if (ev.target.classList[0] === 'ui-icon') {
            if (ev.target.innerText.length > 0) {
                console.log(element);
                refreshCal2(element);
            }
        }
    });
});